# External config directory for VNBASE1C

@author:patazol



This is the directory where 

Eureka configuration files for VNBASE1C do reside in.







